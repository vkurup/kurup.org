// BWDripScreenSaverView -- a reimplementation of a classic Apple ][ program
//                          that dripped water down on the low-res graphics 
//                          screen.

// Copyright (C) 2002 Borkware
// We use the BSD License.  Check out http://borkware.com/license

// Modified: 2003-02-20 vinod@kurup.com
// * Added multiple drips - configurable
// * Configurable block size


#import "BWDripScreenSaverView.h"
#import "BWDripController.h"

// access the memory directly.  No really *good* reason for using
// a macro like this, but it seemed like a fun thing to do at the time

#define blockAddress(pt) (blocks + ((pt.x) + ((pt.y) * width)))
#define blockAt(pt) *blockAddress(pt)
#define setBlockAt(pt, value) *(blockAddress(pt)) = value

// calculate the rectangle for a given point
#define rectFor(pt) \
    NSMakeRect(pt.x*rectSize, pt.y*rectSize, rectSize, rectSize)

@implementation BWDripScreenSaverView


// fill in the playfield with a random assortment of blocks

- (void) setUpPlayfield
{
    int x, y;

    // seed the random number generator
    srandom (time(NULL));

    // walk each block and generate a random number.  If the number is
    // below the 'density' setting, put a new block there

    for (x = 0; x < width; x++) {
	for (y = 0; y < height; y++) {
	    IntPoint point;
	    int urgle = random() % 100;
	    BOOL block = NO;

	    if (urgle < density) {
		block = YES;
	    }

	    point = MakeIntPoint (x, y);
	    setBlockAt (point, DripSpace);

	    if (y > 2 && block) {
		setBlockAt (point, DripBlock);

		// add the block to the list of points to fade in
		fadeInPoints[fadeInPointCount] = point;
		fadeInPointCount++;
	    } else {
		setBlockAt (point, DripSpace);
	    }
	}
    }

    // now randomize the fade in points.  Walk the point list
    // from beginning to end, swapping that point with a random point.
    // quickie, yet pretty good, to permute a collection

    for (x = 0; x < fadeInPointCount; x++) {
	IntPoint swap;
	int index = random() % fadeInPointCount;
	swap = fadeInPoints[x];
	fadeInPoints[x] = fadeInPoints[index];
	fadeInPoints[index] = swap;
    }

    // we're fading in now - so have the animator draw the blocks rather
    // than running the drip around
    fadeIn = YES;

    for (x = 0; x < dripCount ; x++) {
        drips[x] = MakeIntPoint(-1, -1);
    }
    
    [self setNeedsDisplay: YES];

} // setUpPlayfield



// populate a dictionary that holds our 'factory default' tweakable
// parameters (the block density, and the flow rate)

- (NSDictionary *) makeDefaultPreferenceValues
{
    NSDictionary *defaults;

    defaults = [NSDictionary dictionaryWithObjectsAndKeys:
			     [NSNumber numberWithFloat: 25.0], @"density",
			     [NSNumber numberWithFloat: 40.0], @"rate", 
                             [NSNumber numberWithInt: 1], @"drip",
                             [NSNumber numberWithInt: 16], @"blocksize",
			     nil];
    return (defaults);

} // makeDefaultPreferenceValues



// our first entry point.  Allocate the memory we're going to use,
// and get our playfield built

- (id)initWithFrame:(NSRect)frame isPreview:(BOOL)isPreview
{
    int	i;
    if (self = [super initWithFrame: frame  isPreview: isPreview]) {
	ScreenSaverDefaults *userPrefs;
	float dripRate;

	// snarf the tweakable values from the user prefs
	userPrefs = [ScreenSaverDefaults defaultsForModuleWithName: @"BWDrip"];
	[userPrefs registerDefaults: [self makeDefaultPreferenceValues]];

	dripRate = [userPrefs floatForKey: @"rate"];
	density = [userPrefs floatForKey: @"density"];
	dripCount = [userPrefs integerForKey: @"drip"];
	rectSize = [userPrefs integerForKey: @"blocksize"];

	// draw smaller for the preview window.  It actually kind of looks
	// kind of cool in the preview
	if (isPreview) {
	    rectSize = 8;
	}

	// figure out how much area we have to play with, given a constant
	// rect size.
	width = frame.size.width / rectSize;
	height = frame.size.height / rectSize;

	// argh! since the preview window is a freaking *prime* number of
	// pixels across, bump up the rect count to not have a stupid looking
	// unfilled border.
	if (isPreview) {
	    width++;
	    height++;
	}

	// allocate a chunk of memory to hold the blocks, as well
	// as the set of points to fade in.  (yeah, we're allocating
	// a maximal amount of memory here for the fade-in list. we're
	// lazy)

	blocks = calloc (sizeof(DripBlockType) * width * height, 1);
	fadeInPoints = calloc (sizeof(IntPoint) * width * height, 1);
	fadeInPointCount = 0;

	// allocate space for our drips & directions
        drips = calloc(sizeof(IntPoint) * dripCount, 1);
        directions = calloc(sizeof(DripDirection) * dripCount, 1);

        finished = 0;
        
	// finally!  set up the initial set of occupied blocks
	[self setUpPlayfield];

	// and start by falling down
        for (i = 0; i < dripCount; i++) {
            directions[i] = DripDown;
        }
        
        [self setAnimationTimeInterval: 1/dripRate];
    }

    return (self);

} // initWithFrame/isPreview



// clean up our mess and put away our toys.  We're done

- (void) dealloc
{
    free (directions);
    free (drips);
    free (blocks);
    free (fadeInPoints);
    [controller release];

    [super dealloc];

} // dealloc



// this is invoked by the preference sheet when the user says "OK".
// It re-reads the the density and drip rate from the user preferences
// and then rebuilds the playfield

- (void) restart
{
    ScreenSaverDefaults *userPrefs;
    float dripRate;

    userPrefs = [ScreenSaverDefaults defaultsForModuleWithName: @"BWDrip"];

    dripRate = [userPrefs floatForKey: @"rate"];
    [self setAnimationTimeInterval: 1/dripRate];

    density = [userPrefs floatForKey: @"density"];
    dripCount = [userPrefs integerForKey: @"drip"];
    // don't set rectSize here cuz it will change the rectsize
    // in the preview window, which may be too small

    fadeInPointCount = 0;
    [self setUpPlayfield];

} // restart


//
// ------ The Hard-Core (yeah, right) logic for drippyness
//


// given a point, can we move our water blob into it?
// If the point is out of bounds, or if there is something already there
// like a block or more water, then the answer is "NO(e)"

- (BOOL) isValidMoveTo: (IntPoint) point
{
    // make sure it's in bounds
    if (point.x < 0 || point.y < 0 || point.x >= width || point.y >= height) {
	return (NO);

    } else {

	// make sure nothing's there
	if (blockAt(point) == DripSpace) {
	    return (YES);
	} else {
	    return (NO);
	}
    }

} // isValidMoveToXY



// draw the block type at the given point

- (void) fillBlock: (DripBlockType) block  at: (IntPoint) point
{
    NSRect rect;

    // note the highly sophisticated graphics employed

    switch (block) {
        case DripSpace: {
  	    [[NSColor blackColor] set];
	    break;
        }
        case DripBlock: {
  	    [[NSColor yellowColor] set];
	    break;
        }
        case DripWater: {
	  // pick one of 8 colors for our drips
            switch (cur % 8) {
                case 0: {
                    [[NSColor blueColor] set];
                    break;
                }
                case 1: {
                    [[NSColor cyanColor] set];
                    break;
                }
                case 2: {
                    [[NSColor whiteColor] set];
                    break;
                }
                case 3: {
                    [[NSColor lightGrayColor] set];
                    break;
                }
                case 4: {
                    [[NSColor purpleColor] set];
                    break;
                }
                case 5: {
                    [[NSColor orangeColor] set];
                    break;
                }
                case 6: {
                    [[NSColor magentaColor] set];
                    break;
                }
                case 7: {
                    [[NSColor brownColor] set];
                    break;
                }
            }
            break;
        }
        default: {
  	    [[NSColor redColor] set];
	    break;
        }
    }

    rect = rectFor(point);

    [NSBezierPath fillRect: rect];

} // fillBlock



// move the drip from its old point to the new point.  Assumes that drawing
// is focused on us.

- (void) moveTo: (IntPoint) point
{
    // clear out the old
    setBlockAt (drips[cur], DripSpace);
    [self fillBlock: DripSpace  at: drips[cur]];

    // fill in the new
    setBlockAt (point, DripWater);
    [self fillBlock: DripWater  at: point];

    drips[cur] = point;

} // moveTo



// draw the whole playfield.  If we're still fading the blocks in, don't
// draw everything (kind of defeats the purpose of the fade-in)
// at any rate, fill in the background with black

- (void)drawRect:(NSRect)rect
{
    int x, y;

    [[NSColor blackColor] set];
    [NSBezierPath fillRect: rect];

    // necessary to have this for the preview pane

    if (!fadeIn) {
	for (x = 0; x < width; x++) {
	    for (y = 0; y < height; y++) {
		IntPoint point = MakeIntPoint(x, y);
		[self fillBlock: blockAt(point)  at: point];
	    }
	}
    }

} // drawRect



// we're still in fade-in mode.  Draw some of the blocks on each animate
// loop.  

- (void) fadeInOne
{
    int i;
    IntPoint currentPoint;

    // draw 6 blocks each time.  That's just a number that seems to have
    // a good balance between coolness of the fade-in effect, and taking
    // for-ev-er

    for (i = 0; i < 6; i++) {
	currentPoint = fadeInPoints[fadeInPointCount-1];
	
	[self fillBlock: blockAt(currentPoint)  at: currentPoint];
	
	fadeInPointCount--;
	
	// yay!  we're done
	if (fadeInPointCount == 0) {
	    fadeIn = NO;
	    break;
	}
    }

} // fadeInOne



// this gets called by The System for each time we need to animate 
// a frame

- (void)animateOneFrame
{
    IntPoint point;
    int	     i;
    
    // if we're fading in, draw them

    if (fadeIn) {
	[self fadeInOne];
	return;
    }


    // one drip at a time
    for (i = 0; i < dripCount; i++) {
        // set the current drip
        cur = i;
        point = drips[i];

	// if the faucet is off, then skip to next drip
        if (directions[i] == DripStop) {
            continue;
        }
        
        // point.x/y of -1 means that we're starting over with a new drip.

        if (point.x == -1 || point.y == -1) {
	    // set horizontal start pt so drips are staggered across screen
            drips[i].x = (i + 1) * width / (dripCount + 1);

            drips[i].y = 0;
            setBlockAt (drips[i], DripWater);
            directions[i] = DripDown;

            continue;
        }

        // try moving down first

        point.y++;
        if ([self isValidMoveTo: point]) {
            [self moveTo: point];
            directions[i] = DripDown;
            continue;
        }

        // if we got here, we can't move down.  rollback the previous move
        // down
        point.y--;

        // ok, we can't move down.  Try moving left or right

        if (directions[i] == DripDown) {

            // pick a direction at random
            if (random() % 2) {
                directions[i] = DripLeft;
                point.x--;
            } else {
                directions[i] = DripRight;
                point.x++;
            }

            // try moving that direction.  If not, try the other direction.

            if ([self isValidMoveTo: point]) {
                [self moveTo: point];
                // keep moving same direction
                continue;
            }

            // not a valid direction.  try the other direction
            if (directions[i] == DripLeft) {
                directions[i] = DripRight;
                point.x += 2;  // 2 to compensate for the previous move
            } else {
                directions[i] = DripLeft;
                point.x -= 2;  // ditto(e)x
            }

            if ([self isValidMoveTo: point]) {
                // yay!
                [self moveTo: point];
                continue;
            }
	
            // nope, can't move there either.  We're done with this drip.
	    // see if we're near the top of the screen (< 2). if so, this
	    // faucet should be turned off.

            if (point.y < 2) {
	        // turn off the faucet
                directions[i] = DripStop;
                finished++;

		// have we turned off all the faucets?
                if (finished == dripCount) {
		    // restart
                    [self setUpPlayfield];
                    finished = 0;
                    for (i = 0; i < dripCount; i++) {
                        directions[i] = DripDown;
                    }
                }
                continue;
            }

            // start over
            drips[i] = MakeIntPoint (-1, -1);
            directions[i] = DripDown;

            continue;
        }

        // ok, so we're not moving down.  If we're already moving left / right,
        // go that way

        if (directions[i] == DripLeft) {
            point.x--;
        } else if (directions[i] == DripRight) {
            point.x++;
        }

        // try moving there
        if ([self isValidMoveTo: point]) {
            [self moveTo: point];
            // and we'll keep moving same direction
            continue;

        } else {
            // we can't move down, and we can't move any more in the
            // direction we were headed.  We're done with this drip.  start
            // over next time
            drips[i] = MakeIntPoint (-1, -1);
            directions[i] = DripDown;
            continue;
        }

    }
} // animateOneFrame



// yep.  we have a configure sheet

- (BOOL) hasConfigureSheet
{
    return (YES);
} // hasConfigureSheet



// and here it is

- (NSWindow *) configureSheet
{
    if (controller == nil) {
	controller = [[BWDripController alloc] initWithDripView: self];
    }

    return ([controller getConfigureSheet]);

} // configureSheet



// the graphic calculations are a little easier when we're flipped.

- (BOOL) isFlipped
{
    return (YES);
} // isFlipped


@end // BWDripScreenSaverViewGoodnessThisNameIsReallyLong


