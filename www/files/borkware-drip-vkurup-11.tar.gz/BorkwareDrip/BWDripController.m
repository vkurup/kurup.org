// BWDripController.m -- handle the sheet for controlling the various twiddle
//                       knobs of the Drip screen saver

// Copyright (C) 2002 Borkware
// We use the BSD License.  Check out http://borkware.com/license

#import <ScreenSaver/ScreenSaverDefaults.h>

#import "BWDripController.h"
#import "BWDripScreenSaverView.h"



@implementation BWDripController


// initialize ourselves.   Load the sheet that has our sliders and whatnot

- (id) initWithDripView: (BWDripScreenSaverView*) dripView;
{
    if (self = [super init]) {
	view = dripView;
	if (![NSBundle loadNibNamed: @"DripConfigureSheet"  owner: self]) {
	    NSLog (@"oops.  couldn't load bundule");
	}
    }
    
    return (self);

} // init



// The user clicked the OK button.  Store the slider values into the
// user preferences and tell the screensaver to restart itself.  It'll
// pull the values out of the user prefs.

- (IBAction) handleOK: (id) sender
{
    ScreenSaverDefaults *userPrefs;

    userPrefs = [ScreenSaverDefaults defaultsForModuleWithName: @"BWDrip"];
    [userPrefs setFloat: [rateSlider floatValue]  forKey: @"rate"];
    [userPrefs setFloat: [densitySlider floatValue]   forKey: @"density"];
    [userPrefs setInteger: [dripSlider floatValue]   forKey: @"drip"];
    [userPrefs setInteger: [blocksizeSlider floatValue]   forKey: @"blocksize"];
    

    // thanks to http://spazioweb.inwind.it/tpecorella/uselesssoft/mistakes.htm
    // for this one.  Need to manually flush the preferences since sometimes 
    // they don't get automatically saved
    [userPrefs synchronize];

    [NSApp endSheet: configureSheet  returnCode: NSOKButton];

    [view restart];

} // handleOK



// user cancelled.  Don't have to do anything other than end the sheet
// since we don't update the dripView in (sur)real time

- (IBAction) handleCancel: (id) sender
{
    [NSApp endSheet: configureSheet  returnCode: NSCancelButton];

} // handleCancel



// get the window that is our sheet.  Pre-populate it first with the settings
// gotten from the user preferences.

- (NSWindow *) getConfigureSheet
{
    ScreenSaverDefaults *userPrefs;
    userPrefs = [ScreenSaverDefaults defaultsForModuleWithName: @"BWDrip"];

    [userPrefs synchronize];
    
    [rateSlider setFloatValue: [userPrefs floatForKey: @"rate"]];
    [densitySlider setFloatValue: [userPrefs floatForKey: @"density"]];
    [dripSlider setIntValue: [userPrefs integerForKey: @"drip"]];
    [blocksizeSlider setIntValue: [userPrefs integerForKey: @"blocksize"]];

    return (configureSheet);

} // getConfigureSheet


@end // BWDripController

