// BWDripController.h -- handle the sliders and whatnot in the drip screen 
//                       saver's 'Configure' panel

// Copyright (C) 2002 Borkware
// We use the BSD License.  Check out http://borkware.com/license


#import <Cocoa/Cocoa.h>

@class BWDripScreenSaverView;


@interface BWDripController : NSObject
{
    	     BWDripScreenSaverView	*view;

    IBOutlet NSWindow			*configureSheet;

    IBOutlet NSSlider			*densitySlider;
    IBOutlet NSSlider			*rateSlider;
    IBOutlet NSSlider			*dripSlider;
    IBOutlet NSSlider			*blocksizeSlider;
}

- (id) initWithDripView: (BWDripScreenSaverView*) view;

- (IBAction) handleOK: (id) sender;
- (IBAction) handleCancel: (id) sender;

- (NSWindow *) getConfigureSheet;

@end // BWDripController


