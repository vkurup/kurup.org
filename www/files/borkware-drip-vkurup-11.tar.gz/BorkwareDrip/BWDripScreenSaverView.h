// BWDripScreenSaverView.h -- the view our screensaver draws its Good 
//                            Stuff into

// Copyright (C) 2002 Borkware
// We use the BSD License.  Check out http://borkware.com/license

// Modified: 2003-02-20 vinod@kurup.com
// * Added multiple drips - configurable
// * Configurable block size

#import <Cocoa/Cocoa.h>
#import <ScreenSaver/ScreenSaver.h>


// each block in the grid can have three things:
//   * an empty (black) space
//   * a (yellow) block
//   * (colored) water

typedef enum DripBlockType {
    DripSpace,
    DripBlock,
    DripWater
} DripBlockType;


// what direction is our current drip moving?  If it's sliding along
// a flat surface, we have it continuing to move in the same direction
// rather than randomly moving back and forth. DripStop means there's
// no place for the drip to go, so we turn off the faucet. If there's
// more than one drip dripping, then the others continue until they stop

typedef enum DripDirection {
    DripLeft,
    DripRight,
    DripDown,
    DripStop
} DripDirection;


// the drip playfield are integers.  NSPoint won't work since it deals
// with floats

typedef struct IntPoint {
    int x;
    int y;
} IntPoint;


// handy little function to build a point

FOUNDATION_STATIC_INLINE IntPoint MakeIntPoint(x,y) {
    IntPoint p;
    p.x = x;
    p.y = y;
    return (p);
}

// this guy hands the configuration sheet

@class BWDripController;


@interface BWDripScreenSaverView : ScreenSaverView 
{
    DripBlockType	*blocks;
    float		 density;    // block density.  percentage * 100

    int			 rectSize;   // size of the block

    int			 height;     // size of the playfield
    int			 width;

    IntPoint		*drips;      // array of drips
    int			dripCount;   // how many drips are dripping
    int			cur;         // which one is dripping now?
    int			finished;    // how many faucets are off?
    
    DripDirection	*directions; // and the direction it's moving
                                     // one for each drip

    BOOL		 fadeIn;     // draw the blocks incrementally before
    				     // starting to drip
    int			 fadeInPointCount;
    IntPoint		*fadeInPoints;

    BWDripController	*controller; // handles the configuration sheet
}

// recreate the playfield and animate using the configurable parameters
- (void) restart;

@end // BWDripScreenSaverView

